/// <reference types="vite/client" />
declare const __TOKEN_PREFIX__: string;
declare const __BACKEND_URL__: string;
declare const __API_KEY__: string;
