import { Outlet } from "react-router-dom";

const CenterLayout = () => {
  return (
    <section className="h-[100dvh]">
      <div className="flex h-full w-full overflow-hidden rounded-2xl bg-white">
        <div className="relative flex h-full w-[50%] grow flex-col overflow-y-auto overflow-x-hidden px-3 md:px-0">
          <div className="flex w-full flex-1 flex-col items-center justify-center">
            <Outlet />
          </div>
        </div>
      </div>
    </section>
  );
};

export default CenterLayout;
