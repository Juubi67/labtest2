import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Option, Select } from "../components/form-elements/Select";
import countriesWithDialCode from "../utilities/countriesWithDialCode";

const Home = () => {
  const [country, setCountry] = useState("");
  const navigate = useNavigate();
  const query = useMemo(() => {
    navigate(`/get-data?q=${country}`);
  }, [country]);

  return (
    <div
      className="flex w-full flex-col items-center justify-center
    "
    >
      <div className="mx-auto flex flex-col items-center justify-center rounded-xl p-10">
        <h1 className="mt-4 text-2xl">Weather Application</h1>
        <p className="mt-2 max-w-md text-center text-sm text-gray-600">
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque
          vel temporibus porro laborum, cum nemo?
        </p>

        <select
          className="mx-auto mt-5 w-full max-w-sm rounded-xl border p-3 text-sm font-medium"
          value={country}
          onChange={(e) => {
            setCountry(e.target.value);
          }}
          placeholder="Select a country"
        >
          {countriesWithDialCode.map((country) => (
            <option key={country.code} value={country.name}>
              {country.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

export default Home;
