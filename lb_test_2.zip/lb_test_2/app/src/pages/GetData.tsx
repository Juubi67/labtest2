import { useMemo } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import useGetWeatherData from "../api/useGetWeatherData";
import rain from "../assets/rain.jpg";
import sunny from "../assets/sunny.jpg";
import Spinner from "../components/Spinner";
import { Button } from "../components/Button";

const GetData = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const query = useMemo(() => {
    return `${searchParams.get("q")}`;
  }, [searchParams]);

  const { data: weather, isLoading, isError } = useGetWeatherData(query);

  return (
    <div
      className="relative flex w-full flex-col items-center justify-center
    "
    >
      {!isLoading && weather && (
        <>
          <div className="fixed inset-0 z-[10] w-full  ">
            <div className="absolute inset-0 z-[10] bg-gray-950/40"></div>
            <img
              src={
                ["clouds", "rain"].includes(
                  weather.weather[0]?.main?.toLowerCase(),
                )
                  ? rain
                  : sunny
              }
              alt="rain_image"
              className="w-full overflow-hidden bg-cover object-cover"
            />
          </div>

          <div className="relative z-[9999] mx-auto flex w-full items-center justify-center gap-5 rounded-xl p-10">
            <div className="flex flex-col items-center justify-center">
              <h3 className="text-lg font-light tracking-wide text-white">
                {weather.name}
              </h3>

              <h1 className="text-8xl font-thin text-white">
                {weather?.main?.temp}&deg;
              </h1>
              <p className="text-sm text-white">
                {weather?.weather[0]?.description}
              </p>
              <div className="flex items-center justify-center gap-2 text-sm text-white">
                <p>
                  H: <span>{weather?.main?.temp_max}&deg;</span>
                </p>
                <p>
                  L: <span>{weather?.main?.temp_min}&deg;</span>
                </p>
              </div>
            </div>

            <div className="mt-5 grid w-full max-w-xs grid-cols-2 gap-5 text-white">
              <div className="w-full rounded-xl bg-white/20 p-3 backdrop-blur-sm">
                <div className="flex items-center justify-start gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 "
                    viewBox="0 0 256 256"
                  >
                    <g fill="currentColor">
                      <path
                        d="M120 96a24 24 0 1 1 24-24a24 24 0 0 1-24 24Zm88-16a24 24 0 1 0 24 24a24 24 0 0 0-24-24Zm-56 80a24 24 0 1 0 24 24a24 24 0 0 0-24-24Z"
                        opacity=".2"
                      />
                      <path d="M184 184a32 32 0 0 1-32 32c-13.7 0-26.95-8.93-31.5-21.22a8 8 0 0 1 15-5.56C137.74 195.27 145 200 152 200a16 16 0 0 0 0-32H40a8 8 0 0 1 0-16h112a32 32 0 0 1 32 32Zm-64-80a32 32 0 0 0 0-64c-13.7 0-26.95 8.93-31.5 21.22a8 8 0 0 0 15 5.56C105.74 60.73 113 56 120 56a16 16 0 0 1 0 32H24a8 8 0 0 0 0 16Zm88-32c-13.7 0-26.95 8.93-31.5 21.22a8 8 0 0 0 15 5.56C193.74 92.73 201 88 208 88a16 16 0 0 1 0 32H32a8 8 0 0 0 0 16h176a32 32 0 0 0 0-64Z" />
                    </g>
                  </svg>
                  <p className="text-xs uppercase tracking-wider">wind</p>
                </div>
                <div className="mt-3 flex items-center">
                  <h3 className="mr-1 text-4xl font-thin">
                    {weather.wind.speed}
                  </h3>
                  <div className="">
                    <p className="text-xs leading-none text-gray-300">KM/H</p>
                    <p className="mt-1 text-xs leading-none text-gray-100">
                      WIND
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex items-center">
                  <h3 className="mr-1 text-4xl font-thin">
                    {weather.wind.gust}
                  </h3>
                  <div className="">
                    <p className="text-xs leading-none text-gray-300">KM/H</p>
                    <p className="mt-1 text-xs leading-none text-gray-100">
                      GUST
                    </p>
                  </div>
                </div>
              </div>

              <div className="w-full rounded-xl bg-white/20 p-3 backdrop-blur-sm">
                <div className="flex items-center justify-start gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-3 w-3"
                    viewBox="0 0 14 14"
                  >
                    <path
                      fill="currentColor"
                      fill-rule="evenodd"
                      d="m7 .5l.4-.3a.5.5 0 0 0-.8 0l.4.3Zm4.717 10.157A4.997 4.997 0 0 0 12 9c0-.74-.324-1.668-.75-2.588c-.433-.94-1.007-1.944-1.575-2.86A51.756 51.756 0 0 0 7.453.273L7.414.218l-.01-.014l-.003-.003V.2L7 .5L6.6.2l-.001.002l-.003.003l-.01.014l-.039.052l-.145.198a52.374 52.374 0 0 0-1.966 2.906L1.28.22A.75.75 0 1 0 .22 1.28l12.5 12.5a.75.75 0 1 0 1.06-1.06l-2.063-2.063Zm-8.69-4.82l7.08 7.08A5 5 0 0 1 2 9c0-.74.324-1.668.75-2.588c.087-.19.18-.382.277-.575Z"
                      clip-rule="evenodd"
                    />
                  </svg>

                  <p className="text-xs uppercase tracking-wider">humidity</p>
                </div>
                <div className="mt-3 flex items-center">
                  <h3 className="mr-1 text-4xl font-thin">
                    {weather?.main?.humidity}%
                  </h3>
                </div>
              </div>

              <div className="w-full rounded-xl bg-white/20 p-3 backdrop-blur-sm">
                <div className="gap- flex items-center justify-start">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5"
                    viewBox="0 0 48 48"
                  >
                    <path
                      fill="currentColor"
                      fill-rule="evenodd"
                      d="m18.983 29.739l-.002-1.779l-.005-6.211l-.01-12.407c-.002-2.96 2.234-5.36 4.996-5.362c2.761-.002 5.002 2.395 5.004 5.353l.01 12.408l.005 6.212l.002 1.778a8 8 0 1 1-10 .008Zm3.975-8.337c1.196.31 2.562.662 4.019.637l-.002-2.085l-2 .001a1 1 0 0 1-.002-2l2-.001l-.001-2l-2 .001a1 1 0 1 1-.002-2l2-.001l-.002-2l-2 .001a1 1 0 0 1-.001-2l2-.001v-.62c-.002-1.774-1.347-3.212-3.003-3.21c-1.657 0-3 1.44-2.998 3.216l.01 11.641c.585.06 1.252.233 1.982.421Z"
                      clip-rule="evenodd"
                    />
                  </svg>

                  <p className="text-xs uppercase tracking-wider">Feels like</p>
                </div>
                <div className="mt-3 flex items-center">
                  <h3 className="mr-1 text-4xl font-thin">
                    {weather?.main?.feels_like}&deg;
                  </h3>
                </div>

                <p className="mt-5 text-xs">
                  Similar to the actual temperature
                </p>
              </div>

              <div className="w-full rounded-xl bg-white/20 p-3 backdrop-blur-sm">
                <div className="flex items-center justify-start gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5"
                    viewBox="0 0 24 24"
                  >
                    <g fill="none" stroke="currentColor">
                      <path
                        stroke-linecap="round"
                        d="M20.693 17.33a9 9 0 1 0-17.386 0"
                      />
                      <path d="M12.766 15.582c.487.71.144 1.792-.766 2.417c-.91.626-2.043.558-2.53-.151c-.52-.756-2.314-5.007-3.403-7.637c-.205-.495.4-.911.79-.542c2.064 1.96 5.39 5.157 5.909 5.913Z" />
                      <path
                        stroke-linecap="round"
                        d="M12 6v2m-6.364.636L7.05 10.05m11.314-1.414L16.95 10.05m3.743 7.28l-1.931-.518m-15.455.518l1.931-.518"
                      />
                    </g>
                  </svg>

                  <p className="text-xs uppercase tracking-wider">Pressure</p>
                </div>
                <div className="mt-3 flex items-center">
                  <h3 className="mr-1 text-4xl font-thin">
                    {weather?.main?.pressure}{" "}
                    <span className="text-xs">hPa</span>
                  </h3>
                </div>

                <p className="mt-5 text-xs">Similar to the actual pressure</p>
              </div>
            </div>
          </div>
        </>
      )}

      {isLoading && (
        <div className="flex h-full w-full items-center justify-center">
          <Spinner size={"sm"} className="text-gray-800" />
        </div>
      )}

      {isError && !isLoading && (
        <div className="flex h-full w-full flex-col items-center justify-center">
          <p className="text-center text-sm text-gray-600">
            Something went wrong
          </p>

          <Button
            className={
              "mt-3 flex items-center justify-center whitespace-nowrap hover:text-blue-700 hover:underline"
            }
            onClick={() => navigate("/")}
            variant={"ghost"}
          >
            Try again
          </Button>
        </div>
      )}
    </div>
  );
};

export default GetData;
