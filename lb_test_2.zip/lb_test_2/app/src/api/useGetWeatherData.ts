import { useQuery } from "react-query";
import fetcher from "../utilities/fetcher";

const useGetWeatherData = (q: string) => {
  return useQuery({
    queryKey: ["use-weather-data", q],
    queryFn: async () => {
      // const { data } = await fetcher().get(`/data/2.5/weather`, {
      //   params: {
      //     q,
      //     units: "metric",
      //     appid: __API_KEY__,
      //   },
      // });

      // return data;

      return {
        coord: {
          lon: -77.3712,
          lat: 25.0408,
        },
        weather: [
          {
            id: 804,
            main: "Clouds",
            description: "overcast clouds",
            icon: "04d",
          },
        ],
        base: "stations",
        main: {
          temp: 24.45,
          feels_like: 24.57,
          temp_min: 24.45,
          temp_max: 24.45,
          pressure: 1020,
          humidity: 62,
          sea_level: 1020,
          grnd_level: 1018,
        },
        visibility: 10000,
        wind: {
          speed: 6.46,
          deg: 74,
          gust: 7.07,
        },
        clouds: {
          all: 98,
        },
        dt: 1701358502,
        sys: {
          country: "BS",
          sunrise: 1701344218,
          sunset: 1701382775,
        },
        timezone: -18000,
        id: 3572887,
        name: "Bahamas",
        cod: 200,
      };
    },
    retry: 1,
  });
};

export default useGetWeatherData;
